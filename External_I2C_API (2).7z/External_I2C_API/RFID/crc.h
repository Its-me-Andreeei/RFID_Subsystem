#ifndef __CRC_H
#define __CRC_H

#include <stdint.h>
uint16_t compute_crc(const uint8_t *u8Buf, const uint8_t len);

#endif
